#include <string>
#include <cstring>
#include <vector>
#include "DirectoryEntry.hpp"

struct DirectoryTable {
    std::vector<DirectoryEntry> dirEntries;   
};
