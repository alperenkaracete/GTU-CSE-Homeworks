#ifndef __PAGETABLE_CLASS_H__
#define __PAGETABLE_CLASS_H__

#include "pagetable.h"
#include <iostream>

using namespace std;


class PageTable {

    private:
    
    int currentFrame=0, 
    i=0,
    pageNumber=0,
    emptyPages=0;

    public:
    PageTableEntry *entries;
    int *hidedPysicalMemoryNos;
    int size;  // Size of the page table

    PageTable(int tableSize,int physicalFrames);

    ~PageTable();

    void setValueInVirtualMemory(int virtualAddress, int value,int frameSize);
    int getValueInVirtualMemory(int virtualAddress);
    void setEmptyPages(int pageNumber);
    bool isEmptyPages();

};

#endif