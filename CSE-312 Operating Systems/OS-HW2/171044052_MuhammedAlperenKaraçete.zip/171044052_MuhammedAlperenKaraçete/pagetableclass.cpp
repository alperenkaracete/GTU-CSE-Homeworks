#include "pagetableclass.hpp"

PageTable::PageTable(int tableSize,int physicalFrames) {
    size = tableSize;
    entries = new PageTableEntry[size];
    hidedPysicalMemoryNos = new int[physicalFrames*2];
    size = physicalFrames * 2;
    emptyPages = size - physicalFrames;
}

PageTable::~PageTable() {
    delete[] entries;
    delete[] hidedPysicalMemoryNos;
}

void PageTable::setValueInVirtualMemory(int virtualAddress, int value,int frameSize) {
    
    entries[virtualAddress].pageFrameNumber = value;
    currentFrame++;
    if (currentFrame>frameSize-1){
        i++;
        hidedPysicalMemoryNos[i] = value;
        currentFrame=0;
    }

}

int PageTable::getValueInVirtualMemory(int pageNumber) {
    
    for (int i=0;i<size/2;i++){

        if (pageNumber == hidedPysicalMemoryNos[i]){

            break;

        }
    }
    return pageNumber;
}

void PageTable::setEmptyPages(int pageNumber){

    hidedPysicalMemoryNos[size-emptyPages] = pageNumber;
    emptyPages--;
}

bool PageTable::isEmptyPages(){

    if (emptyPages >= 0){

        return 1;
    }

    else {

        return 0;
    }
}