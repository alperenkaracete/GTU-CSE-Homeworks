#include "VirtualMemory.hpp"

VirtualMemory::VirtualMemory(int size)
{
    values = new int[size];
}

VirtualMemory::~VirtualMemory()
{
    delete[] values;
}

void VirtualMemory::setVirtualMemory(int index,int value){

    values[index] = value;
}

int VirtualMemory::getVirtualMemory(int index){

    return values[index];
}