#include "pagetable.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "pagetableclass.hpp"
#include <algorithm>
#include <fstream>
#include <thread>
#include "VirtualMemory.hpp"
#include <climits>
#include <mutex>

mutex memoryAccessMutex;


void secondChance(PageTableEntry* pageTable, int pageTableSize) {
    int hand = 0; // Hand pointer for clock algorithm
    while (true) {
        PageTableEntry* entry = &pageTable[hand];
        if (entry->presentAbsentBit == 1) {
            if (entry->rBit == 1) {
                // Set R bit to 0 and move the page to the end of the list
                entry->rBit = 0;
                hand = (hand + 1) % pageTableSize;
            } else {
                // Page is old and unused, replace it
                entry->presentAbsentBit = 0;
                break;
            }
        }
        hand = (hand + 1) % pageTableSize;
        }
}

void leastRecentlyUsed(PageTableEntry* pageTable, int pageTableSize) {
    int minCounter = INT_MAX;
    int minIndex = -1;
    for (int i = 0; i < pageTableSize; i++) {
        PageTableEntry* entry = &pageTable[i];
        if (entry->presentAbsentBit == 1 && entry->counterC < minCounter) {
            minCounter = entry->counterC;
            minIndex = i;
        }
    }
    if (minIndex != -1) {
        // Replace the page with the minimum counter value
        pageTable[minIndex].presentAbsentBit = 0;
    }
}


//Global variables for threads
int memoryAcces = 0,
    numberOfReads=0,
    numberOfWrites=0,
    numberOfPageMisses=0,
    numberOfPageReplacements=0,
    numberOfDiskPageWrites=0,
    numberOfDiskPageReads=0;

void vectorMatrixMultiply(VirtualMemory &virtualMemory,int yCoordinate,int xCoordinate,int frameSize,vector<int> physicalMemoryFrames,PageTable& pageTable,int memoryAccesses,double result[]){

    int matrix[xCoordinate][yCoordinate];
    int vector[yCoordinate];
    int frameNo=0;

    for (int j = 0; j < yCoordinate; j++) { //fill matrix and vector
        vector[j] = virtualMemory.getVirtualMemory(xCoordinate * yCoordinate + j);

    }

    for (int i=0;i<xCoordinate;i++){
        result[i]=0;
    }

    for (int i=0;i<xCoordinate;i++){
        for (int j=0;j<yCoordinate;j++){
            matrix[i][j] = virtualMemory.getVirtualMemory(i * yCoordinate + j);

        }
    }

    for (int i = 0; i < xCoordinate; i++) {
        for (int j = 0; j < yCoordinate; j++) {
            result[i] += matrix[i][j]*vector[j];
            frameNo = (i+1)*(j+1)/frameSize;
            auto it = std::find(physicalMemoryFrames.begin(), physicalMemoryFrames.end(), frameNo); //It means that phsical memory contains elements that part frame of virtual memory
            if (it != physicalMemoryFrames.end()) {
                
                numberOfWrites++; 

            }
            else {
                numberOfReads++;
                numberOfPageMisses++;
                if (pageTable.isEmptyPages() != 0){ //Page table is empty we can fill

                    pageTable.setValueInVirtualMemory(memoryAcces,frameNo,frameSize);
                    if (memoryAcces % frameSize == 0)
                        pageTable.setEmptyPages(frameNo);
                }
                else {
                    //Page replacement algorithms
                    leastRecentlyUsed(pageTable.entries,pageTable.size);
                }   

            }
            if (memoryAcces % memoryAccesses == 0){
                cout << "Accesed " << memoryAcces << " memory printing page table" << endl;
                for (int i =0;i<pageTable.size;i++){

                    printf ("%dth entry %d\n",i,pageTable.hidedPysicalMemoryNos[i]);
                }
            }
            {
            std::lock_guard<std::mutex> lock(memoryAccessMutex);
            memoryAcces++;
            }
        }

    }

}

void vectorVectorMultiply(VirtualMemory &virtualMemory,int yCoordinate,int xCoordinate,int frameSize,vector<int> physicalMemoryFrames,PageTable& pageTable,int memoryAccesses,double result[]){

    int vector1[xCoordinate*yCoordinate];
    int vector2[yCoordinate*xCoordinate];
    //double result[xCoordinate];
    int frameNo=0;

    for (int j = 0; j < yCoordinate*xCoordinate; j++) { //fill vectors
        vector1[j] = virtualMemory.getVirtualMemory(memoryAcces + j);

    }

    for (int i=0;i<xCoordinate*yCoordinate;i++){
        result[i]=0;
    }

    for (int i=0;i<xCoordinate*yCoordinate;i++){
        
        vector2[i] = virtualMemory.getVirtualMemory(i + memoryAcces);

    }

    for (int i = 0; i < xCoordinate; i++) {
        
            result[i] += vector1[i]*vector2[i];
            frameNo = memoryAcces/frameSize;
            auto it = std::find(physicalMemoryFrames.begin(), physicalMemoryFrames.end(), frameNo); //It means that phsical memory contains elements that part frame of virtual memory
            if (it != physicalMemoryFrames.end()) {
                
                numberOfWrites++; 

            }
            else {
                numberOfReads++;
                numberOfPageMisses++;
                if (pageTable.isEmptyPages() != 0){ //Page table is empty we can fill

                    pageTable.setValueInVirtualMemory(memoryAcces,frameNo,frameSize);
                    if (memoryAcces % frameSize == 0)
                        pageTable.setEmptyPages(frameNo);
                }
                else {
                    //Page replacement algorithms
                }   

            }
            if (memoryAcces % memoryAccesses == 0){
                cout << "Accesed " << memoryAcces << " memory printing page table" << endl;
                for (int i =0;i<pageTable.size;i++){

                    printf ("%dth entry %d\n",i,pageTable.hidedPysicalMemoryNos[i]);
                }
            }
            memoryAcces++;
    }
}

int main(int argc,char* argv[]){

    int frameSize,
    physicalFrames,
    virtualFrames,
    memoryAccesses,
    physicalMemorySize,
    virtualMemorySize;

    char *pageReplacementAlgorithm,
    *pageTableType,
    *diskFileName;

    srand(time(NULL)); 

    if (argc==8){

        frameSize = pow(2,atoi(argv[1]));
        physicalFrames = pow(2,atoi(argv[2]));
        virtualFrames = pow(2,atoi(argv[3]));
        pageReplacementAlgorithm = (char*) malloc(strlen(argv[4]) + 1);
        strcpy(pageReplacementAlgorithm, argv[4]);
        pageTableType = (char*) malloc(strlen(argv[5]) + 1);
        strcpy(pageTableType, argv[5]);
        memoryAccesses = atoi(argv[6]);
        diskFileName = (char*) malloc(strlen(argv[7]) + 1);
        strcpy(diskFileName, argv[7]);
        physicalMemorySize = frameSize*physicalFrames;
        int* physicalMemory = new int[physicalMemorySize];
        virtualMemorySize = frameSize*virtualFrames;
        VirtualMemory virtualMemory(virtualMemorySize);
        PageTable pageTable(virtualMemorySize,physicalFrames);

        ofstream outputFile (diskFileName);
        
        for (int i=0;i<virtualMemorySize;i++){

            virtualMemory.setVirtualMemory(i,rand());

        }

        vector<int> physicalMemoryFrames;
        for (int i=0;i<physicalFrames;i++){

            int temp = rand()%virtualFrames;
            auto it = find(physicalMemoryFrames.begin(), physicalMemoryFrames.end(), temp);
            if (it == physicalMemoryFrames.end()){
                physicalMemoryFrames.push_back(temp);
            }    
            else {
                i--; //THere is duplicate so dont incerement counter.
            }

        }
        sort(physicalMemoryFrames.begin(),physicalMemoryFrames.end());

        for (int i=0;i<physicalFrames;i++){

            for (int j=0;j<frameSize;j++){

                physicalMemory[i*frameSize+j]=virtualMemory.getVirtualMemory(frameSize*physicalMemoryFrames[i]+j);
                pageTable.setValueInVirtualMemory(i,physicalMemoryFrames[i],frameSize);
            }

        }

        for (int i=0;i<virtualFrames;i++){

            auto it = find(physicalMemoryFrames.begin(), physicalMemoryFrames.end(), i);
            if (it == physicalMemoryFrames.end()){
                outputFile << "FrameNo " << i << "\n"; 
                for (int j=0;j<frameSize;j++){
                    outputFile << virtualMemory.getVirtualMemory(frameSize*i+j) << " ";
                }
                outputFile << "\n"; 
            }    
            else {
                continue;

            }

        }
        int firstT = virtualMemorySize/5;
        int coor = firstT/physicalMemorySize;
        double result1[coor];
        
        std::thread thread1([&]() {
            vectorMatrixMultiply(virtualMemory, physicalMemorySize, coor, frameSize, physicalMemoryFrames, pageTable, memoryAccesses, result1);
        });
        thread1.join();
        cout << "Number Of Writes:"<< numberOfWrites << endl;
        cout << "Number Of Reads:"<< numberOfReads << endl;
        cout << "Number Of Page Misses:"<< numberOfPageMisses << endl;
        //vectorVectorMultiply(virtualMemory,physicalMemorySize,coor,frameSize,physicalMemoryFrames,pageTable,memoryAccesses,result2); //causes segmentation fault
        outputFile.close();
        delete[] physicalMemory;
    }

    delete(pageReplacementAlgorithm);
    delete(pageTableType);
    delete(diskFileName);
    
    return 0;
}