#ifndef __VIRTUAL_MEMORY__
#define __VIRTUAL_MEMORY__



class VirtualMemory
{
private:
    /* data */
    int *values;
public:
    VirtualMemory(int size);
    ~VirtualMemory();
    void setVirtualMemory(int index,int value);
    int getVirtualMemory(int index);
};

#endif