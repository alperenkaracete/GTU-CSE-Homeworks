#ifndef __PAGETABLE_H__
#define __PAGETABLE_H__

typedef struct {

    int pageFrameNumber=1,
    presentAbsentBit,
    dirtyBit, //If the page in it has been modified (i.e., is ‘‘dirty’’), it must be written back to the disk. If it has not been modified (i.e., is ‘‘clean’’), it can just be abandoned, since the disk copy is still valid.
    protection, //0 for read/write and 1 for read only
    modified,  //When a page is written to, the hardware automatically sets the Modified bit
    referenced, //The Referenced bit is set whenever a page is referenced, either for reading or for writing. Its value is used to help the operating system choose a page to evict when a page fault occurs. 
    rBit, //For second chace algorithm. if its zero the page is old and unused so its replaced. If its 1 the bit is cleared, the page is put onto the end of the list of pages
    counterC; //For least recently used algorithm. This method requires C counter, that is incremented after each instruction.After each memory reference, the current value of C is stored in the page table entry for the page just referenced.

} PageTableEntry;



#endif