#ifndef FIFO_H   
#define FIFO_H

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define SERVER_FIFO "/tmp/seqnum_sv"
#define CLIENT_FIFO "/tmp/seqnum_cl"


#endif